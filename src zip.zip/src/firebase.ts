import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCY0CeV6SB6oNsU1el7CkvWOy-9jE0ycu0",
  authDomain: "carconnectug-b06c8.firebaseapp.com",
  projectId: "carconnectug-b06c8",
  storageBucket: "carconnectug-b06c8.firebasestorage.app",
  messagingSenderId: "290445203600",
  appId: "1:290445203600:web:994d5e13b37a99a1c1e015"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);