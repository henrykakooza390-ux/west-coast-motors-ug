import { useEffect, useState } from "react";
import PageHeader from "../components/PageHeader";
import { Link } from "react-router-dom";
import { getVehicles } from "../utils/vehicleStorage";
import { getFavorites, removeFromFavorites } from "../utils/favorites";

export default function Favorites() {
  const [cars, setCars] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);

    const allCars = await getVehicles(); // ✅ FIXED
    const favoriteIds = getFavorites();

    const favoriteCars = allCars.filter((car: any) =>
      favoriteIds.includes(car.id)
    );

    setCars(favoriteCars);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const handleRemove = async (id: string) => {
    removeFromFavorites(String(id)); // ✅ FIXED SAFELY
    load(); // ❌ DO NOT await needed here
  };

  if (loading) {
    return <div className="p-8 text-center">Loading favorites...</div>;
  }

  return (
    <>
      <PageHeader
        title="My Favorites"
        subtitle="Your saved vehicles in one place."
      />

      <section className="bg-gradient-to-b from-slate-50 to-white min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

          {cars.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 shadow text-center">
              <h2 className="text-2xl font-bold">No favorites yet</h2>

              <p className="text-gray-500 mt-3">
                Save vehicles using the heart button.
              </p>

              <Link
                to="/"
                className="inline-block mt-6 bg-blue-600 text-white px-6 py-3 rounded-xl"
              >
                Browse Vehicles
              </Link>
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              {cars.map((car: any) => (
                <div
                  key={car.id}
                  className="bg-white rounded-3xl shadow-lg overflow-hidden"
                >
                  <img
                    src={car.image}
                    className="h-52 w-full object-cover"
                  />

                  <div className="p-5">
                    <h3 className="font-bold">
                      {car.make} {car.model}
                    </h3>

                    <p className="text-gray-500">{car.location}</p>

                    <p className="text-blue-600 font-bold mt-2">
                      {car.price}
                    </p>

                    <button
                      onClick={() => handleRemove(car.id)}
                      className="mt-4 bg-red-600 text-white px-4 py-2 rounded-xl"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      </section>
    </>
  );
}