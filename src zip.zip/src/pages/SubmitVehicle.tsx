import { useState } from "react";
import { savePendingVehicle } from "../utils/vehicleStorage";

export default function SubmitVehicle() {
  const [formData, setFormData] = useState({
    make: "",
    model: "",
    year: "",
    price: "",
    location: "",
    bodyType: "",
    mileage: "",
    fuel: "",
    transmission: "",
    engine: "",
    dealer: "",
    phone: "",
    whatsapp: "",
    description: "",
  });

  const [coverImage, setCoverImage] = useState("");
  const [galleryImages, setGalleryImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleCoverImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setCoverImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleGalleryImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);

    const promises = files.map(
      (file) =>
        new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            resolve(reader.result as string);
          };
          reader.readAsDataURL(file);
        })
    );

    Promise.all(promises).then((images) => {
      setGalleryImages(images);
    });
  };

  const handleSubmit = async () => {
    try {
      setLoading(true);

      const vehicle = {
        id: Date.now().toString(),
        ...formData,
        image: coverImage || "/cars/default.jpg",
        images:
          galleryImages.length > 0
            ? galleryImages
            : [coverImage || "/cars/default.jpg"],
        status: "pending",
        featured: false,
        verified: false,
        bestDeal: false,
      };

      await savePendingVehicle(vehicle);

      alert("Vehicle submitted for review!");

      setFormData({
        make: "",
        model: "",
        year: "",
        price: "",
        location: "",
        bodyType: "",
        mileage: "",
        fuel: "",
        transmission: "",
        engine: "",
        dealer: "",
        phone: "",
        whatsapp: "",
        description: "",
      });

      setCoverImage("");
      setGalleryImages([]);
    } catch (error) {
      console.log(error);
      alert("Error submitting vehicle. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 px-4 md:px-8 py-6">

      <div className="max-w-6xl mx-auto">

        <h1 className="text-3xl md:text-4xl font-bold mb-8">
          Submit Vehicle
        </h1>

        <div className="bg-white p-5 md:p-8 rounded-3xl shadow-xl">

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

            <input
              name="make"
              value={formData.make}
              onChange={handleChange}
              placeholder="Make"
              className="border p-3 rounded-xl"
            />

            <input
              name="model"
              value={formData.model}
              onChange={handleChange}
              placeholder="Model"
              className="border p-3 rounded-xl"
            />

            <input
              name="price"
              value={formData.price}
              onChange={handleChange}
              placeholder="Price"
              className="border p-3 rounded-xl"
            />

            <input
              name="location"
              value={formData.location}
              onChange={handleChange}
              placeholder="Location"
              className="border p-3 rounded-xl"
            />

          </div>

          {/* IMAGE UPLOADS */}
          <div className="mt-6">
            <input type="file" onChange={handleCoverImage} />
            <input type="file" multiple onChange={handleGalleryImages} className="mt-3" />
          </div>

          {/* SUBMIT BUTTON */}
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="mt-6 bg-blue-600 text-white px-6 py-3 rounded-xl"
          >
            {loading ? "Submitting..." : "Submit Vehicle"}
          </button>

        </div>

      </div>

    </div>
  );
}