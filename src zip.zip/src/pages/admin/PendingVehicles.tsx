import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  getPendingVehicles,
  approveVehicle,
  rejectVehicle,
} from "../../utils/vehicleStorage";

type Vehicle = {
  id: string;
  make?: string;
  model?: string;
  price?: string;
  image?: string;
  location?: string;
  year?: string;
  mileage?: string;
  fuel?: string;
  transmission?: string;
  dealer?: string;
  phone?: string;
  whatsapp?: string;
  description?: string;
};

export default function PendingVehicleDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  // =========================
  // LOAD VEHICLE
  // =========================
  const loadVehicle = async () => {
    try {
      setLoading(true);

      const vehicles = await getPendingVehicles();

      const found = vehicles.find((v: any) => v.id === id);

      setVehicle(found || null);
    } catch (error) {
      console.log("Error loading vehicle:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicle();
  }, [id]);

  // =========================
  // APPROVE
  // =========================
  const handleApprove = async () => {
    if (!vehicle || actionLoading) return;

    try {
      setActionLoading(true);

      await approveVehicle(vehicle.id);

      alert("Vehicle approved successfully!");

      navigate("/admin/pending");
    } catch (error) {
      console.log("Approve error:", error);
      alert("Failed to approve vehicle.");
    } finally {
      setActionLoading(false);
    }
  };

  // =========================
  // REJECT
  // =========================
  const handleReject = async () => {
    if (!vehicle || actionLoading) return;

    try {
      setActionLoading(true);

      await rejectVehicle(vehicle.id);

      alert("Vehicle rejected successfully!");

      navigate("/admin/pending");
    } catch (error) {
      console.log("Reject error:", error);
      alert("Failed to reject vehicle.");
    } finally {
      setActionLoading(false);
    }
  };

  // =========================
  // LOADING STATE
  // =========================
  if (loading) {
    return (
      <div className="p-8 text-center text-gray-500">
        Loading pending vehicle...
      </div>
    );
  }

  // =========================
  // NOT FOUND
  // =========================
  if (!vehicle) {
    return (
      <div className="p-8 text-center text-gray-600">
        Vehicle not found.
      </div>
    );
  }

  // =========================
  // UI
  // =========================
  return (
    <div className="p-8 bg-gray-100 min-h-screen">

      <h1 className="text-3xl font-bold mb-8">
        Pending Vehicle Review
      </h1>

      <div className="bg-white rounded-3xl shadow-xl p-8">

        {/* IMAGE */}
        <img
          src={vehicle.image || "/cars/default.jpg"}
          alt={`${vehicle.make} ${vehicle.model}`}
          className="w-full h-[450px] object-cover rounded-3xl"
        />

        {/* BASIC INFO */}
        <div className="mt-8">

          <h2 className="text-3xl font-bold">
            {vehicle.make} {vehicle.model}
          </h2>

          <p className="text-blue-600 text-2xl font-bold mt-3">
            {vehicle.price}
          </p>

          <p className="text-gray-500 mt-2">
            {vehicle.location}
          </p>

        </div>

        {/* SPECS */}
        <div className="grid md:grid-cols-4 gap-5 mt-10">

          <div className="bg-gray-50 p-4 rounded-xl">
            <p>Year</p>
            <h3 className="font-bold">{vehicle.year || "N/A"}</h3>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl">
            <p>Mileage</p>
            <h3 className="font-bold">{vehicle.mileage || "N/A"}</h3>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl">
            <p>Fuel</p>
            <h3 className="font-bold">{vehicle.fuel || "N/A"}</h3>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl">
            <p>Transmission</p>
            <h3 className="font-bold">{vehicle.transmission || "N/A"}</h3>
          </div>

        </div>

        {/* SELLER INFO */}
        <div className="mt-10">

          <h2 className="text-2xl font-bold mb-4">
            Seller Information
          </h2>

          <div className="space-y-2">

            <p>
              <strong>Dealer:</strong> {vehicle.dealer || "N/A"}
            </p>

            <p>
              <strong>Phone:</strong> {vehicle.phone || "N/A"}
            </p>

            <p>
              <strong>WhatsApp:</strong> {vehicle.whatsapp || "N/A"}
            </p>

          </div>

        </div>

        {/* DESCRIPTION */}
        <div className="mt-10">

          <h2 className="text-2xl font-bold mb-4">
            Description
          </h2>

          <p className="text-gray-600">
            {vehicle.description || "No description provided"}
          </p>

        </div>

        {/* ACTION BUTTONS */}
        <div className="flex gap-4 mt-10">

          <button
            onClick={handleApprove}
            disabled={actionLoading}
            className="
              bg-green-600
              hover:bg-green-700
              disabled:opacity-50
              text-white
              px-6
              py-3
              rounded-xl
              font-bold
              transition
            "
          >
            {actionLoading ? "Processing..." : "Approve Vehicle"}
          </button>

          <button
            onClick={handleReject}
            disabled={actionLoading}
            className="
              bg-red-600
              hover:bg-red-700
              disabled:opacity-50
              text-white
              px-6
              py-3
              rounded-xl
              font-bold
              transition
            "
          >
            {actionLoading ? "Processing..." : "Reject Vehicle"}
          </button>

        </div>

      </div>

    </div>
  );
}