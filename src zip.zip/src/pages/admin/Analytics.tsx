import { useEffect, useState } from "react";
import { getVehicles } from "../../utils/vehicleStorage";

export default function Analytics() {
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);

      const data = await getVehicles();

      setVehicles(data);

      setLoading(false);
    };

    load();
  }, []);

  const stats = {
    totalVehicles: vehicles.length,
    featured: vehicles.filter(v => v.featured).length,
    bestDeals: vehicles.filter(v => v.bestDeal).length,
    verified: vehicles.filter(v => v.verified).length,
    favorites: 0,
    totalViews: 0,
  };

  if (loading) return <div className="p-8">Loading analytics...</div>;

  return (
    <div className="p-8">

      <h1 className="text-3xl font-bold mb-6">
        Analytics Dashboard
      </h1>

      <div className="grid md:grid-cols-3 gap-4">

        <div>Total: {stats.totalVehicles}</div>
        <div>Featured: {stats.featured}</div>
        <div>Best Deals: {stats.bestDeals}</div>

      </div>

    </div>
  );
}