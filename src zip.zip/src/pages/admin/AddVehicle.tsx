import { useState } from "react";
import { saveVehicle } from "../../utils/vehicleStorage";

export default function AddVehicle() {
  const [featured, setFeatured] = useState(false);
  const [verified, setVerified] = useState(true);
  const [bestDeal, setBestDeal] = useState(false);

  const [coverImage, setCoverImage] = useState("");
  const [galleryImages, setGalleryImages] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    make: "",
    model: "",
    year: "",
    price: "",
    location: "",
    bodyType: "",
    mileage: "",
    fuel: "",
    transmission: "",
    engine: "",
    dealer: "",
    phone: "",
    whatsapp: "",
    description: "",
  });

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement |
      HTMLTextAreaElement |
      HTMLSelectElement
    >
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleCoverImage = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];

    if (!file) return;

    const reader = new FileReader();

    reader.onloadend = () => {
      setCoverImage(reader.result as string);
    };

    reader.readAsDataURL(file);
  };

  const handleGalleryImages = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const files = Array.from(
      e.target.files || []
    );

    const imagePromises = files.map(
      (file) =>
        new Promise<string>((resolve) => {
          const reader = new FileReader();

          reader.onloadend = () => {
            resolve(reader.result as string);
          };

          reader.readAsDataURL(file);
        })
    );

    Promise.all(imagePromises).then(
      (images) => {
        setGalleryImages(images);
      }
    );
  };

  const handleSave = () => {
    const vehicle = {
      id: Date.now(),

      ...formData,

      featured,
      verified,
      bestDeal,

      status: "approved",

      image:
        coverImage ||
        "/cars/default-car.jpg",

      images:
        galleryImages.length > 0
          ? galleryImages
          : [
              coverImage ||
                "/cars/default-car.jpg",
            ],
    };

    saveVehicle(vehicle);

    console.log("Saved vehicle:", vehicle);

    alert("Vehicle saved successfully");

    setFormData({
      make: "",
      model: "",
      year: "",
      price: "",
      location: "",
      bodyType: "",
      mileage: "",
      fuel: "",
      transmission: "",
      engine: "",
      dealer: "",
      phone: "",
      whatsapp: "",
      description: "",
    });

    setCoverImage("");
    setGalleryImages([]);

    setFeatured(false);
    setVerified(true);
    setBestDeal(false);
  };

  return (
    <div className="p-8 bg-gray-100 min-h-screen">
      <h1 className="text-4xl font-bold mb-8">
        Add Vehicle
      </h1>

      <div className="bg-white rounded-3xl shadow-xl p-8">

        <h2 className="text-2xl font-bold mb-6">
          Vehicle Information
        </h2>

        <div className="grid md:grid-cols-2 gap-6">

          <input
            name="make"
            value={formData.make}
            onChange={handleChange}
            placeholder="Make"
            className="border rounded-xl p-4"
          />

          <input
            name="model"
            value={formData.model}
            onChange={handleChange}
            placeholder="Model"
            className="border rounded-xl p-4"
          />

          <input
            name="year"
            value={formData.year}
            onChange={handleChange}
            placeholder="Year"
            className="border rounded-xl p-4"
          />

          <input
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="Price"
            className="border rounded-xl p-4"
          />

          <input
            name="location"
            value={formData.location}
            onChange={handleChange}
            placeholder="Location"
            className="border rounded-xl p-4"
          />

          <select
            name="bodyType"
            value={formData.bodyType}
            onChange={handleChange}
            className="border rounded-xl p-4"
          >
            <option value="">
              Select Body Type
            </option>
            <option>SUV</option>
            <option>Sedan</option>
            <option>Pickup</option>
            <option>Luxury</option>
            <option>Hatchback</option>
            <option>Van</option>
            <option>Crossover</option>
          </select>

        </div>

        <h2 className="text-2xl font-bold mt-12 mb-6">
          Specifications
        </h2>

        <div className="grid md:grid-cols-2 gap-6">

          <input
            name="mileage"
            value={formData.mileage}
            onChange={handleChange}
            placeholder="Mileage"
            className="border rounded-xl p-4"
          />

          <select
            name="fuel"
            value={formData.fuel}
            onChange={handleChange}
            className="border rounded-xl p-4"
          >
            <option value="">
              Fuel Type
            </option>
            <option>Petrol</option>
            <option>Diesel</option>
            <option>Hybrid</option>
            <option>Electric</option>
          </select>

          <select
            name="transmission"
            value={formData.transmission}
            onChange={handleChange}
            className="border rounded-xl p-4"
          >
            <option value="">
              Transmission
            </option>
            <option>Automatic</option>
            <option>Manual</option>
          </select>

          <input
            name="engine"
            value={formData.engine}
            onChange={handleChange}
            placeholder="Engine"
            className="border rounded-xl p-4"
          />

        </div>

        <h2 className="text-2xl font-bold mt-12 mb-6">
          Seller Information
        </h2>

        <div className="grid md:grid-cols-2 gap-6">

          <input
            name="dealer"
            value={formData.dealer}
            onChange={handleChange}
            placeholder="Dealer Name"
            className="border rounded-xl p-4"
          />

          <input
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Phone Number"
            className="border rounded-xl p-4"
          />

          <input
            name="whatsapp"
            value={formData.whatsapp}
            onChange={handleChange}
            placeholder="WhatsApp Number"
            className="border rounded-xl p-4"
          />

        </div>

        <h2 className="text-2xl font-bold mt-12 mb-6">
          Description
        </h2>

        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Vehicle description..."
          className="w-full border rounded-xl p-4 h-40"
        />

        <h2 className="text-2xl font-bold mt-12 mb-6">
          Vehicle Images
        </h2>

        <div className="space-y-8">

          <div>

            <label className="block mb-2 font-semibold">
              Cover Image
            </label>

            <input
              type="file"
              accept="image/*"
              onChange={handleCoverImage}
              className="w-full border rounded-xl p-3"
            />

            {coverImage && (
              <img
                src={coverImage}
                alt="Cover Preview"
                className="mt-4 h-56 rounded-2xl object-cover"
              />
            )}

          </div>

          <div>

            <label className="block mb-2 font-semibold">
              Gallery Images
            </label>

            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleGalleryImages}
              className="w-full border rounded-xl p-3"
            />

            <div className="flex flex-wrap gap-3 mt-4">

              {galleryImages.map(
                (image, index) => (
                  <img
                    key={index}
                    src={image}
                    alt=""
                    className="w-24 h-24 rounded-xl object-cover"
                  />
                )
              )}

            </div>

          </div>

        </div>

        <div className="flex flex-wrap gap-10 mt-10">

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={featured}
              onChange={() =>
                setFeatured(!featured)
              }
            />
            Featured
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={bestDeal}
              onChange={() =>
                setBestDeal(!bestDeal)
              }
            />
            Best Deal
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={verified}
              onChange={() =>
                setVerified(!verified)
              }
            />
            Verified
          </label>

        </div>

        <button
          onClick={handleSave}
          className="
            mt-10
            bg-blue-600
            hover:bg-blue-700
            text-white
            px-8
            py-4
            rounded-xl
            font-semibold
          "
        >
          Save Vehicle
        </button>

      </div>
    </div>
  );
}