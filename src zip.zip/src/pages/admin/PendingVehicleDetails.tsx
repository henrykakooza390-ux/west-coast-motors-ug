import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  getPendingVehicles,
  approveVehicle,
  rejectVehicle,
} from "../../utils/vehicleStorage";

export default function PendingVehicleDetails() {
  const { id } = useParams();
  const [vehicle, setVehicle] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);

      const data = await getPendingVehicles();

      const found = data.find(
        (v: any) => v.id === id
      );

      setVehicle(found || null);

      setLoading(false);
    };

    load();
  }, [id]);

  if (loading) return <div>Loading...</div>;

  if (!vehicle) return <div>Vehicle not found</div>;

  return (
    <div className="p-8">

      <h1>{vehicle.make} {vehicle.model}</h1>

      <button onClick={() => approveVehicle(vehicle.id)}>
        Approve
      </button>

      <button onClick={() => rejectVehicle(vehicle.id)}>
        Reject
      </button>

    </div>
  );
}