import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  getPendingVehicles,
  updatePendingVehicle,
  approveVehicle,
  rejectVehicle,
} from "../../utils/vehicleStorage";

export default function EditPendingVehicle() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [vehicle, setVehicle] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // 🔥 LOAD FROM FIREBASE PROPERLY
  useEffect(() => {
    const loadVehicle = async () => {
      try {
        const pending = await getPendingVehicles();

        const found = pending.find(
          (v: any) => String(v.id) === String(id)
        );

        setVehicle(found || null);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };

    loadVehicle();
  }, [id]);

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    setVehicle({
      ...vehicle,
      [e.target.name]: e.target.value,
    });
  };

  // 💾 SAVE ONLY (NO APPROVE)
  const handleSave = async () => {
    await updatePendingVehicle(String(id), vehicle);
    alert("Pending Vehicle Updated");
  };

  // ✅ APPROVE FLOW
  const handleApprove = async () => {
    await updatePendingVehicle(String(id), vehicle);
    await approveVehicle(String(id));

    alert("Vehicle Approved Successfully");
    navigate("/admin/pending");
  };

  // ❌ REJECT FLOW
  const handleReject = async () => {
    const reason =
      prompt("Enter rejection reason") || "Rejected by admin";

    await rejectVehicle(String(id), reason);

    alert("Vehicle Rejected");
    navigate("/admin/pending");
  };

  if (loading) {
    return <div className="p-8">Loading...</div>;
  }

  if (!vehicle) {
    return <div className="p-8">Vehicle not found</div>;
  }

  return (
    <div className="p-8 bg-gray-100 min-h-screen">

      <h1 className="text-4xl font-bold mb-8">
        Review Pending Vehicle
      </h1>

      <div className="bg-white rounded-3xl shadow-xl p-8">

        <div className="grid md:grid-cols-2 gap-6">

          <input
            name="make"
            value={vehicle.make || ""}
            onChange={handleChange}
            placeholder="Make"
            className="border rounded-xl p-4"
          />

          <input
            name="model"
            value={vehicle.model || ""}
            onChange={handleChange}
            placeholder="Model"
            className="border rounded-xl p-4"
          />

          <input
            name="price"
            value={vehicle.price || ""}
            onChange={handleChange}
            placeholder="Price"
            className="border rounded-xl p-4"
          />

          <input
            name="location"
            value={vehicle.location || ""}
            onChange={handleChange}
            placeholder="Location"
            className="border rounded-xl p-4"
          />

          <input
            name="year"
            value={vehicle.year || ""}
            onChange={handleChange}
            placeholder="Year"
            className="border rounded-xl p-4"
          />

          <input
            name="mileage"
            value={vehicle.mileage || ""}
            onChange={handleChange}
            placeholder="Mileage"
            className="border rounded-xl p-4"
          />

          <input
            name="fuel"
            value={vehicle.fuel || ""}
            onChange={handleChange}
            placeholder="Fuel"
            className="border rounded-xl p-4"
          />

          <input
            name="transmission"
            value={vehicle.transmission || ""}
            onChange={handleChange}
            placeholder="Transmission"
            className="border rounded-xl p-4"
          />

        </div>

        <textarea
          name="description"
          value={vehicle.description || ""}
          onChange={handleChange}
          placeholder="Description"
          className="w-full border rounded-xl p-4 h-40 mt-6"
        />

        <div className="flex gap-10 mt-6">

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={vehicle.featured || false}
              onChange={() =>
                setVehicle({
                  ...vehicle,
                  featured: !vehicle.featured,
                })
              }
            />
            Featured
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={vehicle.bestDeal || false}
              onChange={() =>
                setVehicle({
                  ...vehicle,
                  bestDeal: !vehicle.bestDeal,
                })
              }
            />
            Best Deal
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={vehicle.verified || false}
              onChange={() =>
                setVehicle({
                  ...vehicle,
                  verified: !vehicle.verified,
                })
              }
            />
            Verified
          </label>

        </div>

        <div className="flex gap-4 mt-10">

          <button
            onClick={handleSave}
            className="bg-blue-600 text-white px-6 py-3 rounded-xl"
          >
            Save Changes
          </button>

          <button
            onClick={handleApprove}
            className="bg-green-600 text-white px-6 py-3 rounded-xl"
          >
            Approve Vehicle
          </button>

          <button
            onClick={handleReject}
            className="bg-red-600 text-white px-6 py-3 rounded-xl"
          >
            Reject Vehicle
          </button>

        </div>

      </div>

    </div>
  );
}