import { Link } from "react-router-dom";
import { useVehicles } from "../utils/useVehicles";
import {
  addToCompare,
  removeFromCompare,
  isInCompare,
} from "../utils/compare";

export default function LatestArrivals() {
  const { vehicles, loading } = useVehicles();

  if (loading) return null;

  const latestVehicles = vehicles
    .filter((car: any) => car.status !== "archived")
    .sort((a: any, b: any) => Number(b.id) - Number(a.id))
    .slice(0, 6);

  if (latestVehicles.length === 0) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 md:px-6 py-20">

      {/* HEADER */}

      <div className="mb-12">

        <p className="text-blue-600 font-semibold tracking-wide">
          Recently Added
        </p>

        <h2 className="text-3xl md:text-5xl font-black mt-2">
          Latest Arrivals
        </h2>

      </div>

      {/* GRID */}

      <div
        className="
        grid
        grid-cols-1
        sm:grid-cols-2
        lg:grid-cols-3
        gap-8
        "
      >
        {latestVehicles.map((car: any) => (

          <Link
            key={car.id}
            to={`/vehicle/${car.id}`}
            className="
            relative
            bg-white
            rounded-[32px]
            overflow-hidden
            border border-gray-100
            shadow-lg
            hover:shadow-2xl
            hover:-translate-y-2
            transition-all
            duration-300
            "
          >

            {/* IMAGE */}

            <div className="relative overflow-hidden">

              <img
                src={car.image}
                className="
                w-full
                h-56
                object-cover
                hover:scale-105
                duration-500
                transition
                "
              />

              {/* SOLD */}

              {car.status === "sold" && (
                <span
                  className="
                  absolute
                  top-4
                  left-4
                  bg-red-600
                  text-white
                  px-3
                  py-1
                  text-xs
                  font-bold
                  rounded-full
                  "
                >
                  SOLD
                </span>
              )}

              {/* NEW ARRIVAL */}

              <span
                className="
                absolute
                top-4
                right-4
                bg-green-600
                text-white
                px-3
                py-1
                rounded-full
                text-xs
                font-bold
                "
              >
                NEW ARRIVAL
              </span>

            </div>

            {/* CONTENT */}

            <div className="p-6">

              <h3 className="font-bold text-xl">
                {car.make} {car.model}
              </h3>

              <p className="text-gray-500 mt-1">
                {car.location}
              </p>

              <p className="text-[#2563EB] text-xl font-black mt-4">
                {car.price}
              </p>

              <button
                onClick={(e) => {
                  e.preventDefault();

                  if (isInCompare(car.id)) {
                    removeFromCompare(car.id);
                  } else {
                    addToCompare(car);
                  }
                }}
                className={`
                  mt-5
                  w-full
                  py-3
                  rounded-2xl
                  font-bold
                  transition
                  ${
                    isInCompare(car.id)
                      ? "bg-[#2563EB] text-white"
                      : "bg-gray-100 hover:bg-gray-200"
                  }
                `}
              >
                {isInCompare(car.id)
                  ? "✓ Added To Compare"
                  : "Compare"}
              </button>

            </div>

          </Link>

        ))}
      </div>

    </section>
  );
}