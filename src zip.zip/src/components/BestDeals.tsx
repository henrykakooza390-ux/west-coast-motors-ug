import { Link } from "react-router-dom";
import { useVehicles } from "../utils/useVehicles";
import {
  addToCompare,
  removeFromCompare,
  isInCompare,
} from "../utils/compare";

export default function BestDeals() {
  const { vehicles, loading } = useVehicles();

  if (loading) return null;

  // You can customize the "best deals" logic later
  const deals = vehicles
    .filter((car: any) => car.status !== "archived")
    .slice(0, 6);

  if (deals.length === 0) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 md:px-6 py-14 md:py-20">

      {/* HEADER */}
      <div className="flex items-center justify-between mb-8 md:mb-10">

        <div>
          <p className="text-blue-600 font-semibold text-sm md:text-base">
            Special Offers
          </p>

          <h2 className="text-3xl md:text-4xl font-bold mt-1">
            Best Deals
          </h2>
        </div>

      </div>

      {/* GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">

        {deals.map((car: any) => (

          <Link
            key={car.id}
            to={`/vehicle/${car.id}`}
            className="
              relative
              bg-white
              rounded-3xl
              overflow-hidden
              shadow-lg
              hover:shadow-2xl
              transition
              hover:-translate-y-2
            "
          >

            {/* IMAGE */}
            <div className="relative">

              <img
                src={car.image}
                alt={`${car.make} ${car.model}`}
                className="w-full h-56 object-cover"
              />

              {/* BEST DEAL BADGE */}
              <span
                className="
                absolute
                top-4
                left-4
                bg-red-500
                text-white
                px-3
                py-1
                rounded-full
                text-xs
                font-bold
              "
              >
                BEST DEAL
              </span>

              {/* SOLD BADGE */}
              {car.status === "sold" && (
                <span
                  className="
                  absolute
                  top-4
                  right-4
                  bg-black
                  text-white
                  px-3
                  py-1
                  rounded-full
                  text-xs
                  font-bold
                "
                >
                  SOLD
                </span>
              )}

            </div>

            {/* CONTENT */}
            <div className="p-5">

              <h3 className="font-bold text-xl">
                {car.make} {car.model}
              </h3>

              <p className="text-gray-500 mt-1 text-sm">
                {car.location}
              </p>

              <p className="text-blue-600 font-bold text-lg mt-3">
                {car.price}
              </p>

              <button
                onClick={(e) => {
                  e.preventDefault();

                  if (isInCompare(car.id)) {
                    removeFromCompare(car.id);
                  } else {
                    addToCompare(car);
                  }
                }}
                className={`
                  mt-4
                  w-full
                  py-3
                  rounded-xl
                  font-semibold
                  transition
                  ${
                    isInCompare(car.id)
                      ? "bg-blue-600 text-white"
                      : "bg-gray-200 hover:bg-gray-300"
                  }
                `}
              >
                {isInCompare(car.id)
                  ? "✓ Added To Compare"
                  : "Compare"}
              </button>

            </div>

          </Link>

        ))}

      </div>

    </section>
  );
}