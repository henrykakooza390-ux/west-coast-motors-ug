import { useVehicles } from "../utils/useVehicles";
import { Link } from "react-router-dom";

export default function FeaturedCars() {
  const { vehicles, loading } = useVehicles();

  if (loading)
    return (
      <div className="text-center py-20">
        Loading vehicles...
      </div>
    );

  const cars = vehicles.filter(
    (car) => car.status !== "archived"
  );

  if (cars.length === 0)
    return (
      <div className="text-center py-20">
        No vehicles found.
      </div>
    );

  return (
    <section className="max-w-7xl mx-auto px-4 py-20">

      <h2 className="text-3xl font-bold mb-8">
        Featured Cars
      </h2>

      <div className="grid md:grid-cols-3 gap-6">

        {cars.map((car) => (

          <Link
            key={car.id}
            to={`/vehicle/${car.id}`}
            className="
            bg-white
            rounded-2xl
            shadow-lg
            overflow-hidden
            hover:shadow-2xl
            transition
            "
          >

            <img
              src={car.image}
              className="h-56 w-full object-cover"
            />

            <div className="p-4">

              <h3 className="font-bold">
                {car.make} {car.model}
              </h3>

              <p className="text-blue-600 font-bold mt-2">
                {car.price}
              </p>

              <p className="text-gray-500 mt-1">
                {car.location}
              </p>

            </div>

          </Link>

        ))}

      </div>

    </section>
  );
}