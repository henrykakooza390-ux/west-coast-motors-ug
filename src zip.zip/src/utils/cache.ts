let vehicleCache: any[] | null = null;

export const setVehicleCache = (data: any[]) => {
  vehicleCache = data;
};

export const getVehicleCache = () => {
  return vehicleCache;
};

export const clearVehicleCache = () => {
  vehicleCache = null;
};