import { useEffect, useState } from "react";
import { getVehicles } from "./vehicleStorage";

export function useVehicles() {
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      setLoading(true);

      const data = await getVehicles();

      setVehicles(data);
    } catch (error) {
      console.log("Error loading vehicles:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  return { vehicles, loading, reload: load };
}