import {
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  doc,
  updateDoc,
  getDoc,
  query,
  orderBy,
} from "firebase/firestore";

import { db } from "../firebase";
import { addActivityLog } from "./activityLog";

/* =========================
COLLECTIONS
========================= */

const vehiclesRef = collection(db, "vehicles");
const pendingRef = collection(db, "pendingVehicles");
const rejectedRef = collection(db, "rejectedVehicles");

/* =========================
LIVE VEHICLES
========================= */

export const getVehicles = async () => {
  const q = query(vehiclesRef, orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);

  return snapshot.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  }));
};

export const getVehicleById = async (id: string) => {
  const ref = doc(db, "vehicles", id);
  const snap = await getDoc(ref);

  if (!snap.exists()) return null;

  return {
    id: snap.id,
    ...snap.data(),
  };
};

export const saveVehicle = async (vehicle: any) => {
  const docRef = await addDoc(vehiclesRef, {
    ...vehicle,
    createdAt: Date.now(),
    status: vehicle.status || "approved",
  });

  addActivityLog(
    "Vehicle Added",
    `${vehicle.make} ${vehicle.model}`
  );

  return docRef.id;
};

export const updatePendingVehicle = async (
  id: string,
  updatedData: any
) => {
  const ref = doc(db, "pendingVehicles", id);

  await updateDoc(ref, updatedData);

  addActivityLog(
    "Pending Vehicle Updated",
    id
  );
};

export const updateVehicle = async (
  id: string,
  updatedData: any
) => {
  const ref = doc(db, "vehicles", id);

  await updateDoc(ref, updatedData);

  addActivityLog("Vehicle Updated", id);
};

export const deleteVehicle = async (id: string) => {
  const ref = doc(db, "vehicles", id);

  await deleteDoc(ref);

  addActivityLog("Vehicle Deleted", id);
};

/* =========================
PENDING VEHICLES
========================= */

export const getPendingVehicles = async () => {
  const q = query(pendingRef, orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);

  return snapshot.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  }));
};

export const savePendingVehicle = async (vehicle: any) => {
  await addDoc(pendingRef, {
    ...vehicle,
    status: "pending",
    createdAt: Date.now(),
  });

  addActivityLog(
    "Vehicle Submitted",
    `${vehicle.make} ${vehicle.model}`
  );
};

/* =========================
APPROVE VEHICLE
========================= */

export const approveVehicle = async (id: string) => {
  const pendingDoc = doc(db, "pendingVehicles", id);
  const snap = await getDoc(pendingDoc);

  if (!snap.exists()) return;

  const vehicle = snap.data();

  await addDoc(vehiclesRef, {
    ...vehicle,
    status: "approved",
    approvedAt: Date.now(),
  });

  await deleteDoc(pendingDoc);

  addActivityLog("Vehicle Approved", id);
};

/* =========================
REJECT VEHICLE
========================= */

export const rejectVehicle = async (
  id: string,
  reason: string = "Rejected by admin"
) => {
  const pendingDoc = doc(db, "pendingVehicles", id);
  const snap = await getDoc(pendingDoc);

  if (!snap.exists()) return;

  const vehicle = snap.data();

  await addDoc(rejectedRef, {
    ...vehicle,
    status: "rejected",
    rejectionReason: reason,
    rejectedAt: Date.now(),
  });

  await deleteDoc(pendingDoc);

  addActivityLog("Vehicle Rejected", id);
};

/* =========================
REJECTED VEHICLES
========================= */

export const getRejectedVehicles = async () => {
  const q = query(rejectedRef, orderBy("rejectedAt", "desc"));
  const snapshot = await getDocs(q);

  return snapshot.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  }));
};

export const deleteRejectedVehicle = async (id: string) => {
  const ref = doc(db, "rejectedVehicles", id);
  await deleteDoc(ref);
};

/* =========================
STATUS UPDATES (LIVE)
========================= */

export const markSold = async (id: string) => {
  const ref = doc(db, "vehicles", id);

  await updateDoc(ref, {
    status: "sold",
    soldAt: Date.now(),
  });

  addActivityLog("Vehicle Sold", id);
};

export const archiveVehicle = async (id: string) => {
  const ref = doc(db, "vehicles", id);

  await updateDoc(ref, {
    status: "archived",
  });

  addActivityLog("Vehicle Archived", id);
};

export const restoreVehicle = async (id: string) => {
  const ref = doc(db, "vehicles", id);

  await updateDoc(ref, {
    status: "approved",
  });

  addActivityLog("Vehicle Restored", id);
};