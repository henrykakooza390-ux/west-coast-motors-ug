export const getComparedVehicles = () => {
  const data = localStorage.getItem(
    "carconnect-compare"
  );

  return data ? JSON.parse(data) : [];
};

export const isInCompare = (
  id: number
) => {
  const cars = getComparedVehicles();

  return cars.some(
    (car: any) => car.id === id
  );
};

export const addToCompare = (
  vehicle: any
) => {
  let cars = getComparedVehicles();

  if (
    cars.some(
      (car: any) =>
        car.id === vehicle.id
    )
  )
    return;

  if (cars.length >= 3) {
    alert(
      "You can compare up to 3 vehicles."
    );
    return;
  }

  cars.push(vehicle);

  localStorage.setItem(
    "carconnect-compare",
    JSON.stringify(cars)
  );

  window.dispatchEvent(
    new Event("compareUpdated")
  );
};

export const removeFromCompare = (
  id: number
) => {
  const cars =
    getComparedVehicles().filter(
      (car: any) =>
        car.id !== id
    );

  localStorage.setItem(
    "carconnect-compare",
    JSON.stringify(cars)
  );

  window.dispatchEvent(
    new Event("compareUpdated")
  );
};

export const clearCompare = () => {
  localStorage.removeItem(
    "carconnect-compare"
  );

  window.dispatchEvent(
    new Event("compareUpdated")
  );
};