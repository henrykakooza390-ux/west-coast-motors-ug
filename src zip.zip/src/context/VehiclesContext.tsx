import {
  createContext,
  useContext,
  useEffect,
  useState,
} from "react";

import { getVehicles } from "../utils/vehicleStorage";

type Vehicle = any;

type VehiclesContextType = {
  vehicles: Vehicle[];
  loading: boolean;
  refreshVehicles: () => Promise<void>;
};

const VehiclesContext = createContext<VehiclesContextType | null>(null);

export function VehiclesProvider({ children }: { children: ReactNode }) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshVehicles = async () => {
    try {
      setLoading(true);

      const data = await getVehicles();

      setVehicles(data);
    } catch (error) {
      console.log("Vehicle load error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshVehicles();
  }, []);

  return (
    <VehiclesContext.Provider
      value={{
        vehicles,
        loading,
        refreshVehicles,
      }}
    >
      {children}
    </VehiclesContext.Provider>
  );
}

export function useVehiclesContext() {
  const context = useContext(VehiclesContext);

  if (!context) {
    throw new Error(
      "useVehiclesContext must be used inside VehiclesProvider"
    );
  }

  return context;
}